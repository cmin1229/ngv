Drivers/STM32G0xx_HAL_Driver/stm32g0xx_hal_flash_ex.o: \
 E:/files/STM32CubeG0-master/STM32CubeG0-master/Drivers/STM32G0xx_HAL_Driver/Src/stm32g0xx_hal_flash_ex.c \
 ../../../../../../../Drivers/STM32G0xx_HAL_Driver/Inc/stm32g0xx_hal.h \
 ../../Inc/stm32g0xx_hal_conf.h \
 ../../../../../../../Drivers/STM32G0xx_HAL_Driver/Inc/stm32g0xx_hal_rcc.h \
 ../../../../../../../Drivers/STM32G0xx_HAL_Driver/Inc/stm32g0xx_hal_def.h \
 ../../../../../../../Drivers/CMSIS/Include/stm32g0xx.h \
 ../../../../../../../Drivers/CMSIS/Include/stm32g0b1xx.h \
 ../../../../../../../Drivers/CMSIS/Include/core_cm0plus.h \
 ../../../../../../../Drivers/CMSIS/Include/cmsis_version.h \
 ../../../../../../../Drivers/CMSIS/Include/cmsis_compiler.h \
 ../../../../../../../Drivers/CMSIS/Include/cmsis_gcc.h \
 ../../../../../../../Drivers/CMSIS/Include/mpu_armv7.h \
 ../../../../../../../Drivers/CMSIS/Include/system_stm32g0xx.h \
 ../../../../../../../Drivers/STM32G0xx_HAL_Driver/Inc/Legacy/stm32_hal_legacy.h \
 ../../../../../../../Drivers/STM32G0xx_HAL_Driver/Inc/stm32g0xx_ll_rcc.h \
 ../../../../../../../Drivers/STM32G0xx_HAL_Driver/Inc/stm32g0xx_hal_rcc_ex.h \
 ../../../../../../../Drivers/STM32G0xx_HAL_Driver/Inc/stm32g0xx_hal_gpio.h \
 ../../../../../../../Drivers/STM32G0xx_HAL_Driver/Inc/stm32g0xx_hal_gpio_ex.h \
 ../../../../../../../Drivers/STM32G0xx_HAL_Driver/Inc/stm32g0xx_hal_dma.h \
 ../../../../../../../Drivers/STM32G0xx_HAL_Driver/Inc/stm32g0xx_ll_dma.h \
 ../../../../../../../Drivers/STM32G0xx_HAL_Driver/Inc/stm32g0xx_ll_dmamux.h \
 ../../../../../../../Drivers/STM32G0xx_HAL_Driver/Inc/stm32g0xx_hal_dma_ex.h \
 ../../../../../../../Drivers/STM32G0xx_HAL_Driver/Inc/stm32g0xx_hal_cortex.h \
 ../../../../../../../Drivers/STM32G0xx_HAL_Driver/Inc/stm32g0xx_hal_adc.h \
 ../../../../../../../Drivers/STM32G0xx_HAL_Driver/Inc/stm32g0xx_ll_adc.h \
 ../../../../../../../Drivers/STM32G0xx_HAL_Driver/Inc/stm32g0xx_hal_adc_ex.h \
 ../../../../../../../Drivers/STM32G0xx_HAL_Driver/Inc/stm32g0xx_hal_adc_ex.h \
 ../../../../../../../Drivers/STM32G0xx_HAL_Driver/Inc/stm32g0xx_hal_exti.h \
 ../../../../../../../Drivers/STM32G0xx_HAL_Driver/Inc/stm32g0xx_hal_flash.h \
 ../../../../../../../Drivers/STM32G0xx_HAL_Driver/Inc/stm32g0xx_hal_flash_ex.h \
 ../../../../../../../Drivers/STM32G0xx_HAL_Driver/Inc/stm32g0xx_hal_pwr.h \
 ../../../../../../../Drivers/STM32G0xx_HAL_Driver/Inc/stm32g0xx_hal_pwr_ex.h
../../../../../../../Drivers/STM32G0xx_HAL_Driver/Inc/stm32g0xx_hal.h:
../../Inc/stm32g0xx_hal_conf.h:
../../../../../../../Drivers/STM32G0xx_HAL_Driver/Inc/stm32g0xx_hal_rcc.h:
../../../../../../../Drivers/STM32G0xx_HAL_Driver/Inc/stm32g0xx_hal_def.h:
../../../../../../../Drivers/CMSIS/Include/stm32g0xx.h:
../../../../../../../Drivers/CMSIS/Include/stm32g0b1xx.h:
../../../../../../../Drivers/CMSIS/Include/core_cm0plus.h:
../../../../../../../Drivers/CMSIS/Include/cmsis_version.h:
../../../../../../../Drivers/CMSIS/Include/cmsis_compiler.h:
../../../../../../../Drivers/CMSIS/Include/cmsis_gcc.h:
../../../../../../../Drivers/CMSIS/Include/mpu_armv7.h:
../../../../../../../Drivers/CMSIS/Include/system_stm32g0xx.h:
../../../../../../../Drivers/STM32G0xx_HAL_Driver/Inc/Legacy/stm32_hal_legacy.h:
../../../../../../../Drivers/STM32G0xx_HAL_Driver/Inc/stm32g0xx_ll_rcc.h:
../../../../../../../Drivers/STM32G0xx_HAL_Driver/Inc/stm32g0xx_hal_rcc_ex.h:
../../../../../../../Drivers/STM32G0xx_HAL_Driver/Inc/stm32g0xx_hal_gpio.h:
../../../../../../../Drivers/STM32G0xx_HAL_Driver/Inc/stm32g0xx_hal_gpio_ex.h:
../../../../../../../Drivers/STM32G0xx_HAL_Driver/Inc/stm32g0xx_hal_dma.h:
../../../../../../../Drivers/STM32G0xx_HAL_Driver/Inc/stm32g0xx_ll_dma.h:
../../../../../../../Drivers/STM32G0xx_HAL_Driver/Inc/stm32g0xx_ll_dmamux.h:
../../../../../../../Drivers/STM32G0xx_HAL_Driver/Inc/stm32g0xx_hal_dma_ex.h:
../../../../../../../Drivers/STM32G0xx_HAL_Driver/Inc/stm32g0xx_hal_cortex.h:
../../../../../../../Drivers/STM32G0xx_HAL_Driver/Inc/stm32g0xx_hal_adc.h:
../../../../../../../Drivers/STM32G0xx_HAL_Driver/Inc/stm32g0xx_ll_adc.h:
../../../../../../../Drivers/STM32G0xx_HAL_Driver/Inc/stm32g0xx_hal_adc_ex.h:
../../../../../../../Drivers/STM32G0xx_HAL_Driver/Inc/stm32g0xx_hal_adc_ex.h:
../../../../../../../Drivers/STM32G0xx_HAL_Driver/Inc/stm32g0xx_hal_exti.h:
../../../../../../../Drivers/STM32G0xx_HAL_Driver/Inc/stm32g0xx_hal_flash.h:
../../../../../../../Drivers/STM32G0xx_HAL_Driver/Inc/stm32g0xx_hal_flash_ex.h:
../../../../../../../Drivers/STM32G0xx_HAL_Driver/Inc/stm32g0xx_hal_pwr.h:
../../../../../../../Drivers/STM32G0xx_HAL_Driver/Inc/stm32g0xx_hal_pwr_ex.h:
